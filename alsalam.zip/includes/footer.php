  <footer class="site-footer" id="contact">
    <div class="container">
      <p>© <?= date('Y') ?> مطعم السلام — جميع الحقوق محفوظة</p>
      <p>📍 البيض، الجزائر &nbsp;•&nbsp; 📞 اتصل للطلب أو استعمل الموقع مباشرة</p>
    </div>
  </footer>
</body>
</html>
